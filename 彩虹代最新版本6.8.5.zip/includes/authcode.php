<?php
$authcode='不知道这是啥';
$distid='也不知道这是啥';

?>